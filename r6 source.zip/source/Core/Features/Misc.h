#pragma once

namespace Misc
{
	void Movement() noexcept;
	void Physics() noexcept;
	void ChatInteraction() noexcept;
}