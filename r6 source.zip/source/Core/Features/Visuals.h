#pragma once

namespace Visuals
{
	void Renderables() noexcept;
	void Effects() noexcept;
};