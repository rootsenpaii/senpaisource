#pragma once

namespace Aimbot
{
	void Run() noexcept;
	void Silent() noexcept;
};