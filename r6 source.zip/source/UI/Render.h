#pragma once
#include <d3d12.h>
#include <dxgi1_4.h>
#include <wrl.h>
#include <cmath>
#include <vector>
#include <imgui.h>
#include "imgui_impl_dx12.h"

inline ID3D12Device* g_pd3dDevice = nullptr;
inline ID3D12DescriptorHeap* g_pd3dSrvDescHeap = nullptr;
inline ID3D12GraphicsCommandList* g_pd3dCommandList = nullptr;

struct ImFont;

#define SCALE(value) (value * Render::Size / 100.f)

enum Chanel : int
{
    AIMBOT = 0,
    VISUALS,
    MISC,
    SETTINGS,
    SEARCH
};

namespace Render
{

    void Initialize(ID3D12Device* device, ID3D12DescriptorHeap* srvDescHeap);
    void Render();
    void Cleanup();

    inline ID3D12Device* g_Device = nullptr;
    inline ID3D12DescriptorHeap* g_SrvDescHeap = nullptr;
    inline ID3D12GraphicsCommandList* g_CommandList = nullptr;

    void Fonts() noexcept;
    void Style() noexcept;
    void Menu() noexcept;

    inline ImFont* MenuFont = nullptr;

    inline float Size = 100.f;
    inline float tempSize = Size;

    inline int SelectedChanel = AIMBOT;

    inline std::vector<std::pair<Chanel, const char*>> channelButtons = {
    { AIMBOT, "Aimbot" },
    { VISUALS, "Visuals" },
    { MISC, "Misc" },
    { SETTINGS, "Settings" }
    };

    inline ImColor AccentColor = ImColor(0.878f, 0.067f, 0.373f, 1.0f); // .f
    inline static char searchBuffer[20] = "";
};
