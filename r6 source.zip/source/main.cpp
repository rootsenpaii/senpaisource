#include <Windows.h>
#include <iostream>

#include "UI/UI.h"
#include "Engine/Engine.h"

void CheckDirectXVersion();

void Setup(const HMODULE instance)
{
	CheckDirectXVersion();
	try
	{
		//Engine::Get()->SetupConsole();

		gui::Setup();
		gui::SetupHook();
	}
	catch (const std::exception& error)
	{
		MessageBoxA(
			0,
			error.what(),
			"Load Error",
			MB_OK | MB_ICONEXCLAMATION
		);

		goto UNLOAD;
	}

	while (!GetAsyncKeyState(VK_END))
		std::this_thread::sleep_for(std::chrono::milliseconds(200));


UNLOAD:
	gui::DestroyHook();
	gui::Destroy();

	FreeLibraryAndExitThread(instance, 0);
};


void CheckDirectXVersion()
{
	if (GetModuleHandleA("d3d12.dll"))
		MessageBoxA(nullptr, "Game is running with DirectX 12", "DX Version", MB_OK | MB_ICONINFORMATION);
	else if (GetModuleHandleA("d3d11.dll"))
		MessageBoxA(nullptr, "Game is running with DirectX 11", "DX Version", MB_OK | MB_ICONINFORMATION);
	else
		MessageBoxA(nullptr, "Cannot detect DirectX version", "DX Version", MB_OK | MB_ICONWARNING);
}


BOOL WINAPI DllMain(const HMODULE instance, const uintptr_t reason, const void* reserved)
{
	if (reason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(instance);

		const auto thread = CreateThread(
			nullptr,
			0,
			reinterpret_cast<LPTHREAD_START_ROUTINE>(Setup),
			instance,
			0,
			nullptr
		);

		if (thread)
			CloseHandle(thread);
	};

	return TRUE;
};