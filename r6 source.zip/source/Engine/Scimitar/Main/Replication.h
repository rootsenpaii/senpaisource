#pragma once

struct Vftable;

class Replication
{
public:
	//Vftable* vtable;

	const char* GetName() noexcept;
};