#pragma once

class ubiVector3;

namespace scimitar
{
	bool isVisible(ubiVector3 src, ubiVector3 dst);
}